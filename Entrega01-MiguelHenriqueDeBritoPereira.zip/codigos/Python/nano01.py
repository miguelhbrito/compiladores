def main() -> None:
    return

