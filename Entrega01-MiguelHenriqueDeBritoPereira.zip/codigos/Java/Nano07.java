public class Nano07 {
    public static void main(String[] args) {
        int n;
        n = 1;
        if(n==1){
            System.out.println(n);
        }
    }    
}
