public class Nano10 {
    public static void main(String[] args) {
        int n, m;
        n = 1;
        m = 2;
        if(n==m){
            System.out.println(n);
        }else{
            System.out.println(0);
        }
    }
    
}
