public class Nano01 {  
    public static void main(String[] args) {       
    }    
}
