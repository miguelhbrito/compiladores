public class Nano04 {
    public static void main(String[] args) {
       int n;
       n = 1+2;
    }
}
