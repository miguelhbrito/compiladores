public class Nano02 {
    public static void main(String[] args) {
       int n;
    }
 }
