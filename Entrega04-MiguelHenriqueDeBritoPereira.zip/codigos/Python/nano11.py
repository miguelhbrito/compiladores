def main() -> None:
    n: int = 1
    m: int = 2
    x: int = 5
    while x > n:
        n = n + m
        print(n)

main()
