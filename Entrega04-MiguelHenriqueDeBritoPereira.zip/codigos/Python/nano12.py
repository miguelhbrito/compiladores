def main() -> None:
    n: int = 1
    m: int = 2
    x: int = 5
    while x > n:
       if n == m:
           print(n)
       else:
           print(0)
       x = x - 1

main()
