def main() -> None:
    n: int = 0

