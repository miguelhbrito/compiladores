def main() -> None:
    n = 1
    if n == 1:
        print(n)

main()
