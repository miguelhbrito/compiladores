def main() -> None:
    n: int = 1 + (1 / 2)
    if n == 1:
        print(n)
    else:
        print(0)

main()
