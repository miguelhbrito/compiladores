public class Nano12 {
    public static void main(String[] args) {
        int n, m, x;
        n = 1;
        m = 2;
        x = 5;
        while(x>n){
            if(n==m)
                System.out.println(n);
            else
                System.out.println(0);
            x = x - 1;
        }
    }
}

