def main() -> None:
    n: int = 2
    print(n)

main()
