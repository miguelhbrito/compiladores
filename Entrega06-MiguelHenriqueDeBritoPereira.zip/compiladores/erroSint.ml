
(* This file was auto-generated based on "sintatico.msg". *)

(* Please note that the function [message] can raise [Not_found]. *)

let message =
  fun s ->
    match s with
    | 1 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 46 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 18 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 19 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 26 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 27 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 20 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 21 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 22 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 28 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 29 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 34 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 35 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 30 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 31 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 32 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 33 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 36 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 37 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 38 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 39 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 42 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 43 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 47 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 48 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 49 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 144 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 24 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 25 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 40 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 41 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 9 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 8 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 44 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 0 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 50 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 201 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 53 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 51 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 54 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 55 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 14 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 15 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 57 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 59 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 60 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 61 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 62 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 63 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 162 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 163 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 164 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 165 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 166 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 169 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 170 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 171 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 172 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 173 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 175 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 76 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 77 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 78 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 80 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 81 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 83 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 84 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 86 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 87 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 89 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 111 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 113 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 114 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 115 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 116 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 117 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 118 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 119 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 120 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 122 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 97 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 98 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 100 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 101 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 102 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 103 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 104 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 105 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 106 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 107 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 109 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 10 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 146 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 64 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 65 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 66 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 67 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 68 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 69 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 70 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 71 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 72 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 73 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 74 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 75 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 148 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 149 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 150 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 151 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 152 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 153 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 154 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 155 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 156 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 157 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 158 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 181 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 182 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 183 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 184 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 186 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 187 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 190 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 191 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 192 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 193 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 194 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | 195 ->
        "<YOUR SYNTAX ERROR MESSAGE HERE>\n"
    | _ ->
        raise Not_found
