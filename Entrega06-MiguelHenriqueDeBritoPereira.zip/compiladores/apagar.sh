#!/bin/bash
rm -f erroSint.ml fnmes.ml semanticoTest.byte sintaticoTest.byte interpreteTest.byte cod3endTest.byte sintatico.automaton sintatico.conflicts sintatico.messages
rm -R "_build"
