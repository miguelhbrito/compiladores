public class Nano06 {
    public static void main(String[] args) {
        int n;
        n = 1-2;
        System.out.println(n);
    }    
}
