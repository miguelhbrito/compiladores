public class Nano03 {    
    public static void main(String[] args) {
        int n;
        n = 1;
    }    
}
