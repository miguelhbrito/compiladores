def main() -> None:
    n: int = 1 - 2
    print(n)

main()
